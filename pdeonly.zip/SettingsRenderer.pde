class SettingsRenderer {

  float angle = 0;
  float targetAngle = 0;
  float rotateSpeed = 0.12;

  float iconX = 550;
  float iconY = 350;

  boolean wasHovering = false;
  boolean settingsOpen = false;
  float hoverAmount = 0;
  float hoverSpeed = 0.15;

  float baseSize = 50;
  float hoverSize = 60;

  color baseColor = color(224);
  color hoverColor = color(120, 190, 255);

  PShape playerIcon;
  PShape botIcon;

  UIComponents ui = new UIComponents();

  int pendingEngineMode = 2;
  int pendingElo = 3200;
  boolean pendingWhiteBot = false;
  boolean pendingBlackBot = true;
  int pendingTimeLimit = 600;

  String[] engineNames = {"Experimentell", "Smart", "Auto"};

  void init() {
    playerIcon = loadShape("images/device-player.svg");
    botIcon = loadShape("images/device-bot.svg");
  }

  void rotateBy(float radiansToAdd) {
    targetAngle += radiansToAdd;
  }

  void rotateTo(float newTarget) {
    targetAngle = newTarget;
  }

  boolean isHovering() {
    return iconHit() && !mousePressed;
  }

  boolean iconHit() {
    return mouseX > iconX && mouseX < iconX + baseSize - 5 && mouseY > iconY && mouseY < iconY + baseSize - 5;
  }

  void onMousePressed() {
    if (!settingsOpen || overlayRenderer.pauseGameDueToAnimation) return;
    ui.onMousePressed();
  }

  void onKeyPressed() {
    if (!settingsOpen || overlayRenderer.pauseGameDueToAnimation) return;
    ui.onKeyPressed();
  }

  void toggleSettings() {
    if (overlayRenderer.pauseGameDueToAnimation) return;
    if (settingsOpen) closeSettings();
    else openSettings();
  }

  void openSettings() {
    pendingEngineMode = gameStatus.engineMode;
    pendingElo = gameStatus.stockfishElo;
    pendingWhiteBot = gameStatus.enginePlayAsWhite;
    pendingBlackBot = gameStatus.enginePlayAsBlack;
    pendingTimeLimit = gameStatus.timeLimit;
    settingsOpen = true;
  }

  void closeSettings() {
    ui.blur();
    settingsOpen = false;
  }

  void tickSettings() {
    ui.enabled = settingsOpen && !overlayRenderer.pauseGameDueToAnimation;

    boolean hovering = isHovering();
    if (hovering && !wasHovering && abs(targetAngle - angle) < 0.05) {
      rotateBy(PI);
    }
    wasHovering = hovering;

    float hoverTarget = hovering ? 1 : 0;
    hoverAmount = lerp(hoverAmount, hoverTarget, hoverSpeed);
    if (abs(hoverTarget - hoverAmount) < 0.005) hoverAmount = hoverTarget;

    angle = lerp(angle, targetAngle, rotateSpeed);
    if (abs(targetAngle - angle) < 0.001) angle = targetAngle;

    float currentSize = lerp(baseSize, hoverSize, hoverAmount);
    float centerX = iconX + baseSize / 2;
    float centerY = iconY + baseSize / 2;

    drawSettingsIcon(
      centerX - currentSize / 2,
      centerY - currentSize / 2,
      currentSize
      );

    if (settingsOpen) drawSettingsFrame();
    ui.endFrame();
  }

  void drawSettingsIcon(float x, float y, float size) {
    float s = size / 32.0;

    pushStyle();
    pushMatrix();

    translate(x + size / 2, y + size / 2);
    rotate(angle);
    scale(s);

    noFill();
    stroke(lerpColor(baseColor, hoverColor, hoverAmount));
    strokeWeight(2);
    strokeJoin(ROUND);
    strokeCap(ROUND);

    int teeth = 6;
    float outerR = 12;
    float rootR = 9;
    float step = TWO_PI / teeth;

    beginShape();
    for (int i = 0; i < teeth; i++) {
      float a = radians(90) + i * step;

      vertex(cos(a - radians(20)) * rootR, sin(a - radians(20)) * rootR);
      vertex(cos(a - radians(12)) * outerR, sin(a - radians(12)) * outerR);
      vertex(cos(a + radians(12)) * outerR, sin(a + radians(12)) * outerR);
      vertex(cos(a + radians(20)) * rootR, sin(a + radians(20)) * rootR);
      vertex(cos(a + radians(30)) * rootR, sin(a + radians(30)) * rootR);
    }
    endShape(CLOSE);
    ellipseMode(CENTER);
    ellipse(0, 0, 8, 8);

    popMatrix();
    popStyle();
  }
  
  String getPlayerTypeSummary(){
    String w = gameStatus.enginePlayAsWhite ? "Bot" : "Spieler";
    String b = gameStatus.enginePlayAsBlack ? "Bot" : "Spieler";
    return w + " vs. " + b;
  }

  void drawSettingInfoSummary() {
    if (overlayRenderer.currentAnimation.equals("Checkmate")) return;
    textSize(16);
    textAlign(CENTER);
    String w = gameStatus.enginePlayAsWhite ? "Bot" : "Spieler";
    String b = gameStatus.enginePlayAsBlack ? "Bot" : "Spieler";
    text(w + "/" + b, 512, 270);
    int basePos = 512;
    float offsetOfText = (textWidth(w + "/" + b) / 2.0);
    shape(gameStatus.enginePlayAsWhite ? botIcon : playerIcon, basePos - offsetOfText - 30, 255, 20, 20);
    shape(gameStatus.enginePlayAsBlack ? botIcon : playerIcon, basePos + offsetOfText + 10, 255, 20, 20);
  }

  String formatTime(float seconds) {
    int total = round(seconds);
    return (total / 60) + ":" + nf(total % 60, 2);
  }

  void applySettings() {
    gameStatus.engineMode = pendingEngineMode;
    gameStatus.stockfishElo = pendingElo;
    gameStatus.enginePlayAsWhite = pendingWhiteBot;
    gameStatus.enginePlayAsBlack = pendingBlackBot;
    gameStatus.timeLimit = pendingTimeLimit;
    closeSettings();
  }

  void drawSettingsFrame() {
    pushStyle();
    rectMode(CORNER);
    fill(30, 30, 30);
    stroke(70);
    strokeWeight(5);
    rect(50, 50, width - 100, height - 100);
    popStyle();

    float x = 90;
    float w = width - 180;

    pushStyle();
    fill(255);
    textSize(22);
    textAlign(LEFT, CENTER);
    text("Einstellungen", x, 70);
    popStyle();

    pendingEngineMode = 1 + ui.segmented("engineMode", "Engine", x, 86, w, engineNames,
      pendingEngineMode - 1, (i) -> pendingEngineMode = i + 1);

    if (pendingEngineMode == 2) {
      ui.slider("elo", "Stockfish-Elo", x, 130, w, 1320, 3200, 10, pendingElo, (v) -> pendingElo = round(v));
    } else {
      ui.label("Engine-Elo", x, 136);
      pushStyle();
      fill(255);
      textSize(14);
      textAlign(RIGHT, CENTER);
      text(pendingEngineMode == 1 ? "500" : "~", x + w, 136);
      popStyle();
    }

    ui.slider("timeLimit", "Zeitlimit", x, 166, w, 30, 5400, 30, pendingTimeLimit,
      (v) -> formatTime(v), (v) -> pendingTimeLimit = round(v));

    ui.toggle("whiteBot", "Weiß spielt als Bot", x, 206, pendingWhiteBot, (v) -> pendingWhiteBot = v);
    ui.toggle("blackBot", "Schwarz spielt als Bot", x + 200, 206, pendingBlackBot, (v) -> pendingBlackBot = v);

    ui.designPicker("design", "Brett-Design", x, 232, w, rendererBaseLayout.designs,
      gameStatus.playingFieldDesign, (i) -> gameStatus.playingFieldDesign = i);

    float by = height - 50 - 16 - 34;
    float bw = (w - 10) / 2;
    ui.button("apply", "Übernehmen", x, by, bw, 34, true, () -> overlayRenderer.startConfirmSetting());
    ui.button("restart", "Neues Spiel", x + bw + 10, by, bw, 34, false, () -> {
      closeSettings();
      overlayRenderer.newGameCalled();
    }
    );
  }
}
