interface FloatCallback  { void call(float v); }
interface BoolCallback   { void call(boolean v); }
interface IntCallback    { void call(int v); }
interface StringCallback { void call(String v); }
interface FloatFormatter { String format(float v); }

class UIComponents {

  boolean enabled = true;

  color textCol  = color(255);
  color dimCol   = color(195, 205, 220);
  color accent   = color(120, 190, 255);
  color panelCol = color(35, 40, 55);
  color hoverCol = color(55, 62, 82);
  color trackCol = color(70);

  String activeId = null;
  String focusId = null;
  String focusBuffer = "";
  StringCallback focusCb = null;
  boolean focusNumeric = false;
  int focusMaxLen = 16;

  boolean pressedThisFrame = false;
  HashMap<String, Float> anim = new HashMap<String, Float>();

  void onMousePressed() {
    if (!enabled) return;
    pressedThisFrame = true;
  }

  void onKeyPressed() {
    if (!enabled || focusId == null) return;

    if (key == ENTER || key == RETURN) {
      commitFocus();
    } else if (key == ESC) {
      key = 0;
      focusId = null;
    } else if (key == BACKSPACE) {
      if (focusBuffer.length() > 0) focusBuffer = focusBuffer.substring(0, focusBuffer.length() - 1);
    } else if (key != CODED && key >= 32 && key < 127 && focusBuffer.length() < focusMaxLen) {
      if (!focusNumeric || (key >= '0' && key <= '9')) focusBuffer += key;
    }
  }

  void endFrame() {
    if (!enabled) focusId = null;
    if (pressedThisFrame && focusId != null) commitFocus();
    if (!mousePressed || !enabled) activeId = null;
    pressedThisFrame = false;
  }

  void blur() {
    if (focusId != null) commitFocus();
    activeId = null;
    pressedThisFrame = false;
  }

  void commitFocus() {
    String result = focusBuffer;
    StringCallback cb = focusCb;
    focusId = null;
    focusCb = null;
    if (cb != null) cb.call(result);
  }

  boolean take(boolean over) {
    if (!enabled || !pressedThisFrame || !over) return false;
    pressedThisFrame = false;
    return true;
  }

  boolean hit(float x, float y, float w, float h) {
    return mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h;
  }

  float animTo(String key, float target, float speed) {
    Float prev = anim.get(key);
    float a = (prev == null) ? target : prev;
    a = lerp(a, target, speed);
    if (abs(a - target) < 0.005) a = target;
    anim.put(key, a);
    return a;
  }

  void label(String s, float x, float y) {
    pushStyle();
    fill(dimCol);
    textSize(14);
    textAlign(LEFT, CENTER);
    text(s, x, y);
    popStyle();
  }

  float slider(String id, String lbl, float x, float y, float w,
               float minV, float maxV, float step, float value, FloatCallback cb) {
    return slider(id, lbl, x, y, w, minV, maxV, step, value, null, cb);
  }

  float slider(String id, String lbl, float x, float y, float w,
               float minV, float maxV, float step, float value, FloatFormatter fmt, FloatCallback cb) {
    float trackY = y + 22;
    boolean over = enabled && hit(x - 8, trackY - 12, w + 16, 24);

    if (activeId == null && take(over)) activeId = id;

    if (enabled && id.equals(activeId) && mousePressed) {
      float t = constrain((mouseX - x) / w, 0, 1);
      float nv = minV + t * (maxV - minV);
      if (step > 0) nv = minV + round((nv - minV) / step) * step;
      nv = constrain(nv, minV, maxV);
      if (nv != value) {
        value = nv;
        if (cb != null) cb.call(nv);
      }
    }

    float t = (maxV == minV) ? 0 : (value - minV) / (maxV - minV);

    pushStyle();
    rectMode(CORNER);
    ellipseMode(CENTER);
    label(lbl, x, y + 6);
    fill(textCol);
    textSize(14);
    textAlign(RIGHT, CENTER);
    text(fmt != null ? fmt.format(value) : (step >= 1 ? str(round(value)) : nf(value, 0, 2)), x + w, y + 6);

    noStroke();
    fill(trackCol);
    rect(x, trackY - 2, w, 4, 2);
    fill(accent);
    rect(x, trackY - 2, w * t, 4, 2);
    fill(textCol);
    ellipse(x + w * t, trackY, 14, 14);
    popStyle();
    return value;
  }

  boolean toggle(String id, String lbl, float x, float y, boolean value, BoolCallback cb) {
    float tw = 40, th = 20;
    pushStyle();
    rectMode(CORNER);
    ellipseMode(CENTER);
    textSize(16);
    float totalW = tw + 12 + textWidth(lbl);
    boolean over = enabled && hit(x, y, totalW, th);

    if (take(over)) {
      value = !value;
      if (cb != null) cb.call(value);
    }

    float a = animTo(id, value ? 1 : 0, 0.3);

    noStroke();
    fill(lerpColor(trackCol, accent, a));
    rect(x, y, tw, th, th / 2);
    fill(255);
    ellipse(x + th / 2 + a * (tw - th), y + th / 2, th - 6, th - 6);

    fill(textCol);
    textAlign(LEFT, CENTER);
    text(lbl, x + tw + 12, y + th / 2 - 1);
    popStyle();
    return value;
  }

  String textField(String id, String lbl, float x, float y, float w, String value,
                   int maxLen, boolean numericOnly, StringCallback cb) {
    float fy = y + 14, fh = 26;
    boolean over = enabled && hit(x, fy, w, fh);
    boolean focused = id.equals(focusId);

    if (take(over)) {
      if (focusId != null && !focused) commitFocus();
      if (!focused) {
        focusId = id;
        focusBuffer = value;
        focusCb = cb;
        focusNumeric = numericOnly;
        focusMaxLen = maxLen;
        focused = true;
      }
    }

    String shown = focused ? focusBuffer : value;

    pushStyle();
    rectMode(CORNER);
    label(lbl, x, y + 6);
    fill(panelCol);
    if (focused) {
      stroke(accent);
      strokeWeight(2);
    } else {
      noStroke();
    }
    rect(x, fy, w, fh, 6);

    noStroke();
    fill(textCol);
    textSize(16);
    textAlign(LEFT, CENTER);
    text(shown, x + 8, fy + fh / 2 - 1);
    if (focused && (millis() / 500) % 2 == 0) {
      float cx = x + 9 + textWidth(shown);
      stroke(textCol);
      strokeWeight(1);
      line(cx, fy + 5, cx, fy + fh - 5);
    }
    popStyle();
    return shown;
  }

  int segmented(String id, String lbl, float x, float y, float w, String[] options,
                int selected, IntCallback cb) {
    float fy = y + 14, fh = 26;
    float segW = w / options.length;

    if (take(enabled && hit(x, fy, w, fh))) {
      int idx = constrain(floor((mouseX - x) / segW), 0, options.length - 1);
      if (idx != selected) {
        selected = idx;
        if (cb != null) cb.call(idx);
      }
    }

    pushStyle();
    rectMode(CORNER);
    label(lbl, x, y + 6);
    noStroke();
    textSize(16);
    textAlign(CENTER, CENTER);
    for (int i = 0; i < options.length; i++) {
      boolean over = enabled && hit(x + i * segW, fy, segW, fh);
      fill(i == selected ? accent : (over ? hoverCol : panelCol));
      rect(x + i * segW, fy, segW - 4, fh, 6);
      fill(i == selected ? color(20) : textCol);
      text(options[i], x + i * segW + (segW - 4) / 2, fy + fh / 2 - 1);
    }
    popStyle();
    return selected;
  }

  void button(String id, String lbl, float x, float y, float w, float h, boolean primary, Runnable cb) {
    boolean over = enabled && hit(x, y, w, h);
    if (take(over) && cb != null) cb.run();

    pushStyle();
    rectMode(CORNER);
    noStroke();
    if (primary) fill(over ? lerpColor(accent, color(255), 0.2) : accent);
    else fill(over ? hoverCol : panelCol);
    rect(x, y, w, h, 8);
    fill(primary ? color(20) : textCol);
    textSize(17);
    textAlign(CENTER, CENTER);
    text(lbl, x + w / 2, y + h / 2 - 1);
    popStyle();
  }

  void arrowButton(float x, float y, float w, float h, boolean left, boolean over, boolean active) {
    noStroke();
    fill(over && active ? hoverCol : panelCol);
    rect(x, y, w, h, 6);
    fill(active ? textCol : color(90));
    float cx = x + w / 2;
    float cy = y + h / 2;
    if (left) triangle(cx + 4, cy - 6, cx + 4, cy + 6, cx - 5, cy);
    else triangle(cx - 4, cy - 6, cx - 4, cy + 6, cx + 5, cy);
  }

  int designPicker(String id, String lbl, float x, float y, float w,
                   int[][][] designs, int selected, IntCallback cb) {
    float tile = 30, gap = 8, arrowW = 26;
    float fy = y + 14;
    float viewX = x + arrowW + 8;
    float viewW = w - 2 * (arrowW + 8);
    float stride = tile + gap;
    int count = designs.length;
    int visible = floor((viewW + gap) / stride);
    float maxScroll = max(0, count - visible);

    if (anim.get(id + "T") == null) {
      float start = constrain(selected - visible / 2.0, 0, maxScroll);
      anim.put(id + "T", start);
      anim.put(id + "S", start);
      anim.put(id + "P", (float) selected);
    }

    float target = anim.get(id + "T");

    boolean overL = enabled && hit(x, fy, arrowW, tile);
    boolean overR = enabled && hit(x + w - arrowW, fy, arrowW, tile);
    if (take(overL)) target = constrain(round(target) - 1, 0, maxScroll);
    if (take(overR)) target = constrain(round(target) + 1, 0, maxScroll);
    anim.put(id + "T", target);

    float scroll = animTo(id + "S", target, 0.2);
    float selPos = animTo(id + "P", selected, 0.25);

    boolean inView = enabled && hit(viewX, fy, viewW, tile);
    for (int i = 0; i < count; i++) {
      float tx = viewX + (i - scroll) * stride;
      if (take(inView && hit(tx, fy, tile, tile))) {
        if (i != selected) {
          selected = i;
          if (cb != null) cb.call(i);
        }
      }
    }

    pushStyle();
    rectMode(CORNER);
    noStroke();
    label(lbl, x, y + 6);

    arrowButton(x, fy, arrowW, tile, true, overL, target > 0);
    arrowButton(x + w - arrowW, fy, arrowW, tile, false, overR, target < maxScroll);

    clip(viewX - 2, fy - 2, viewW + 4, tile + 4);
    float half = tile / 2;
    for (int i = 0; i < count; i++) {
      float tx = viewX + (i - scroll) * stride;
      if (tx + tile < viewX - 2 || tx > viewX + viewW + 2) continue;
      color light = color(designs[i][0][0], designs[i][0][1], designs[i][0][2]);
      color dark = color(designs[i][1][0], designs[i][1][1], designs[i][1][2]);
      fill(light);
      rect(tx, fy, half, half);
      rect(tx + half, fy + half, half, half);
      fill(dark);
      rect(tx + half, fy, half, half);
      rect(tx, fy + half, half, half);
    }
    noFill();
    stroke(accent);
    strokeWeight(3);
    rect(viewX + (selPos - scroll) * stride, fy, tile, tile, 3);
    noClip();
    popStyle();
    return selected;
  }
}
